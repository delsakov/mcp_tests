# vllm-ms4 image — provenance and Mistral Large 3 support

## TL;DR

- The container's vLLM is a **source checkout** of `https://github.com/juliendenize/vllm.git` (a Mistral AI employee's fork), installed editably from `/workspace/vllm`. Reported version: `0.0.0+precompiled`.
- HEAD: `8e6f4314e` ("Fix no tools path") on branch `fix_mistral_parsing`.
- The fork is **far ahead of vLLM v0.21.0** — its base is post-Dec-2025 upstream main (PRs in the #36000–37000 range).
- "Mistral 4 Small" in the user's terminology = **`MistralLarge3ForCausalLM`** in registered form. Mistral's internal/marketing name and the public/code name differ.
- Support for this architecture is **already in upstream vLLM main**, via two upstream-merged PRs by juliendenize:
  - **PR #29757** (commit `d8c6210ee`, 2025-12-02) — "Add Mistral Large 3 and Ministral 3"
  - **PR #36163** (commit `afebeffbf`, 2026-03-11) — "Add support to Mistral large 3 eagle with dense layers"
- The 6 fork-only commits on top of upstream are tool-calling / parsing / guided-decoding polish. **None of them touch model code.**
- To get Mistral Large 3 working in mainline vLLM, you do **not** need to cherry-pick from juliendenize/vllm — you need any upstream vLLM build that includes PR #29757 (and #36163 if you want Eagle speculative decoding). v0.21.0 is too old.

---

## What version / commit is the custom image built from?

| Field | Value |
|---|---|
| Reported version | `0.0.0+precompiled` |
| Install style | editable (PEP 660), `direct_url.json` = `{"dir_info": {"editable": true}, "url": "file:///workspace/vllm"}` |
| Source path | `/workspace/vllm` (NamespaceLoader; not a wheel) |
| dist-info | `/usr/local/lib/python3.12/dist-packages/vllm-0.0.0+precompiled.dist-info` |
| Git remote | `origin = https://github.com/juliendenize/vllm.git` |
| HEAD | `8e6f4314e` "Fix no tools path" (detached, matches branch `origin/fix_mistral_parsing`) |
| Working tree | clean |

The python `vllm.__version__` attribute is **not** exposed by this build (raises `AttributeError`) — use `vllm._version.__version__` via the file directly, or the dist-info METADATA.

### Fork-specific commits (6 commits, all by `julien.denize@mistral.ai`)

```
8e6f4314e  Fix no tools path
b59d6cef3  Enforce 'auto' tool choice
465119e99  fix mypy
114ee57ba  Fix mypy
5fee4b022  Improvement
76803b168  Add Mistral Guidance       (committed by slurm cluster build user)
458c1a4b2  ← merge base with upstream-style commits ("[Frontend] Reduce chat template warmup logging levels (#37062)" by Nick Hill)
```

Stat of `git diff 458c1a4b2 HEAD` — i.e. everything the fork adds on top of upstream:

```
 tests/reasoning/test_mistral_reasoning_parser.py    |  54 +
 tests/tool_parsers/test_mistral_tool_parser.py      | 534 ++
 tests/v1/structured_output/test_backend_guidance.py |  38 +
 vllm/entrypoints/openai/chat_completion/serving.py  | 194 +
 vllm/entrypoints/openai/engine/serving.py           |  88 -+
 vllm/entrypoints/serve/render/serving.py            |  16 -+
 vllm/sampling_params.py                             |  16 -+
 vllm/tokenizers/mistral.py                          | 129 +
 vllm/tool_parsers/mistral_tool_parser.py            | 360 ++
 vllm/v1/structured_output/backend_guidance.py       |  18 -+
 vllm/v1/structured_output/backend_types.py          |   1 +
 vllm/v1/structured_output/backend_xgrammar.py       |   5 +
 vllm/v1/structured_output/request.py                |   2 +
 13 files changed, 1354 insertions(+), 101 deletions(-)
```

Notice: **zero changes under `vllm/model_executor/`**. The model-architecture support is entirely in the upstream-portion of the tree.

---

## What enables Mistral Large 3 (aka the user's "Mistral 4 Small")?

### Files (all sourced from upstream PR #29757 + #36163, not fork-specific)

| File | LOC | Role |
|---|---|---|
| `vllm/model_executor/models/mistral_large_3.py` | 63 | **The whole model.** Thin subclass of `DeepseekV3ForCausalLM` with a regex weight-name remapping table |
| `vllm/model_executor/models/mistral_large_3_eagle.py` | 141 | Eagle-style speculative-decoding draft model wrapping `DeepseekV2Model` |
| `vllm/model_executor/models/registry.py` (edited) | +5 | Registers `MistralLarge3ForCausalLM` and `EagleMistralLarge3ForCausalLM` |
| `vllm/model_executor/models/deepseek_v2.py` (edited) | +66 | Tweaks needed in the DeepSeek-V2 base path to support Mistral's variant |
| `vllm/model_executor/layers/mla.py` (edited) | +4 | MLA attention support tweaks |
| `vllm/model_executor/layers/rotary_embedding/__init__.py` (edited) | +2 | Rotary embedding registration |
| `vllm/transformers_utils/configs/mistral.py` (edited) | +74 | Parse Mistral config format into HF-style for Mistral Large 3 |
| `vllm/transformers_utils/configs/eagle.py` (edited) | +6 | Eagle draft model config |
| `vllm/tokenizers/mistral.py` (edited) | +36 | Tokenizer support |
| `vllm/config/speculative.py` (edited) | +4 | Recognize `EagleMistralLarge3ForCausalLM` as a draft model type |
| `vllm/v1/spec_decode/eagle.py` (edited) | +4 | Spec-decode wiring |
| `vllm/entrypoints/openai/tool_parsers/mistral_tool_parser.py` (edited) | +2 | Minor |
| `vllm/model_executor/layers/fused_moe/configs/E=128,N=512,device_name=NVIDIA_H200,dtype=fp8_w8a8.json` | 146 | **New FP8 fused-MoE kernel tuning** for E=128 experts, N=512 intermediate, H200 |
| `tests/models/registry.py` (edited) | +14 | Test registry entry |
| `tests/tokenizers_/test_mistral.py` (edited) | +158 | Tokenizer tests |

Total PR #29757: **+724 / −30 across 16 files.**
Total PR #36163: **+28 / −1 across 2 files** (extends Eagle to support dense-layer prefix).

### What the architecture actually is

`mistral_large_3.py` is **literally** this:

```python
class MistralLarge3ForCausalLM(DeepseekV3ForCausalLM):
    remapping = {
        r"layers\.(\d+)\.attention_norm\.weight":     r"model.layers.\1.input_layernorm.weight",
        r"layers\.(\d+)\.attention\.wq_a\.(\w+)":     r"model.layers.\1.self_attn.q_a_proj.\2",
        r"layers\.(\d+)\.attention\.q_a_norm\.weight":r"model.layers.\1.self_attn.q_a_layernorm.weight",
        r"layers\.(\d+)\.attention\.wq_b\.(\w+)":     r"model.layers.\1.self_attn.q_b_proj.\2",
        r"layers\.(\d+)\.attention\.wkv_a_with_mqa\.(\w+)": r"model.layers.\1.self_attn.kv_a_proj_with_mqa.\2",
        r"layers\.(\d+)\.attention\.kv_a_norm\.weight":r"model.layers.\1.self_attn.kv_a_layernorm.weight",
        r"layers\.(\d+)\.attention\.wkv_b\.(\w+)":    r"model.layers.\1.self_attn.kv_b_proj.\2",
        r"layers\.(\d+)\.attention\.wo\.(\w+)":       r"model.layers.\1.self_attn.o_proj.\2",
        r"layers\.(\d+)\.ffn_norm\.weight":           r"model.layers.\1.post_attention_layernorm.weight",
        r"layers\.(\d+)\.feed_forward\.w1\.(\w+)":    r"model.layers.\1.mlp.gate_proj.\2",
        r"layers\.(\d+)\.feed_forward\.w2\.(\w+)":    r"model.layers.\1.mlp.down_proj.\2",
        r"layers\.(\d+)\.feed_forward\.w3\.(\w+)":    r"model.layers.\1.mlp.up_proj.\2",
        r"layers\.(\d+)\.gate\.weight":               r"model.layers.\1.mlp.gate.weight",
        r"layers\.(\d+)\.shared_experts\.w[123]\.(\w+)": "...",       # shared experts
        r"layers\.(\d+)\.experts\.(\d+)\.w[123]\.(\w+)": "...",       # routed experts
        r"norm\.weight":                              "model.norm.weight",
        r"tok_embeddings\.weight":                    "model.embed_tokens.weight",
        r"output\.weight":                            "lm_head.weight",
    }

    def load_weights(self, weights):
        return super().load_weights(map(self._remap_mistral_to_ds, weights))

    def _remap_mistral_to_ds(self, weight):
        name, t = weight
        for k, v in self.remapping.items():
            if re.fullmatch(k, name):
                name = re.sub(k, v, name)
                break
        else:
            raise ValueError(f"Cannot remap {name}")
        if name.endswith(".qscale_act"):    name = name[:-len(".qscale_act")]    + ".input_scale"
        if name.endswith(".qscale_weight"): name = name[:-len(".qscale_weight")] + ".weight_scale"
        return name, t
```

**Architectural conclusion:** Mistral Large 3 / Ministral 3 is **structurally the same as DeepSeek-V3** — MLA attention (`q_a_proj` / `q_b_proj` / `kv_a_proj_with_mqa` / `kv_b_proj` with separate layernorms) plus MoE with shared experts and routed experts. All vLLM needs is:

1. A weight-name remapping (Mistral uses `wq_a` / `feed_forward.w1` / `experts.N.w1`; DeepSeek uses `q_a_proj` / `mlp.gate_proj` / `experts.N.gate_proj`).
2. An FP8 scale remapping (`qscale_act` → `input_scale`, `qscale_weight` → `weight_scale`).
3. The 16-file scaffold above for config parsing, tokenizer, MLA tweaks, rotary, MoE kernel tuning, and Eagle support.

The "~119B MoE" sizing is consistent with a DeepSeek-V3-style MoE.

---

## Registry entries that get the architecture wired in

```python
# vllm/model_executor/models/registry.py
"MistralLarge3ForCausalLM": ("mistral_large_3", "MistralLarge3ForCausalLM"),
"EagleMistralLarge3ForCausalLM": (
    "mistral_large_3_eagle",
    "EagleMistralLarge3ForCausalLM",
),
```

---

## What's NOT in this HEAD (still on origin branches but unmerged)

The fork has several unmerged feature branches that might matter depending on the user's goals:

```
origin/add_mistral_large_3            32f0bbcda   (in-progress / superseded)
origin/add_320_dim                    1910ddf06   320-dim head support
origin/nvfp4_support                  ???         NVFP4 quantization
origin/nvpf4_calibration_ds                       NVFP4 calibration
origin/cache_mistral_tokenizer
origin/improve_mistral_format
origin/fix_mistral_config
origin/mistral_common_v10             (already merged into HEAD via PR #36971)
origin/eagle_support
origin/max_len_support
origin/juliendenize/fix_pixtral_staged_vision_loading
...
```

The current HEAD's `fix_mistral_parsing` branch is one of these.

---

## Cherry-pick recipe to add Mistral Large 3 to mainline vLLM 0.21.0

**Honest assessment: don't.** v0.21.0 is ~6 months older than PR #29757 and lacks too many prerequisites (MLA refactors, MoE layer changes, `SupportsEagle` interface, MLA rotary embedding APIs, FP8 fused-MoE kernel infra, `support_torch_compile`, `RowParallelLinear.return_bias`, etc.). The diff "vs v0.21.0" is **not really a cherry-pick** — it's "drag in six months of vLLM upstream."

**Recommended path:** upgrade to a vLLM main / release that contains **commit `d8c6210ee` (PR #29757)** — anything tagged after early-Dec-2025. For Eagle support, also need **commit `afebeffbf` (PR #36163)** — anything after mid-March 2026.

If you genuinely must back-port to 0.21.0, the prerequisite list and the 16-file PR (saved in `diffs/`) are the starting point — expect this to be a multi-week effort, not a clean cherry-pick.

---

## Artifacts in this folder

```
vllm-diff/
├── SUMMARY.md                    ← this file
├── mistral_large_3.py            ← copied from container (63 LOC)
├── mistral_large_3_eagle.py      ← copied from container (141 LOC)
├── registry.py                   ← copied from container (full file, for context)
└── diffs/
    ├── registry_PR29757.diff           ← +5 lines registering the two arches
    ├── deepseek_v2_PR29757.diff        ← +66 lines: tweaks to DeepSeek-V2 needed by Mistral Large 3
    ├── support_changes_PR29757.diff    ← MLA, rotary, config, tokenizer, speculative, eagle, tool-parser edits
    └── eagle_dense_PR36163.diff        ← full PR #36163 (Eagle dense-layer support)
```

The two `mistral_large_3*.py` files contain the **complete fork model code** for this architecture — nothing else is hidden elsewhere in the fork. The rest of the support (MLA, MoE, config) is just minimal edits to existing files.
